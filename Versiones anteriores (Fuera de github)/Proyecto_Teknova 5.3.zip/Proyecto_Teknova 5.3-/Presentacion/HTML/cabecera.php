<?php
include_once '../../Negocio/usuario.php';
session_start();
if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit();
}
?>

<header class="barra-superior">
    <section class="Usuario">
        <img class="img-Usuario" src="https://i.imgur.com/dI9Sv1L.png" alt="Foto del Usuario">
        <aside class="NombreyAjustes">
            <h5 class="nombre-Usuario"><?php echo $_SESSION['usuario']->getNombre(); ?></h5>
            <a href="Ajustes.php" class="ajustes">Ajustes</a>
            <a href="login.php" class="login">login</a>
        </aside>
    </section>
    <img src="https://i.imgur.com/Elnz5fv.png" alt="Logo Draftosaurus" class="logo-central">
    <img src="https://i.imgur.com/lNgoRWb.png" alt="Logo Teknova" class="logo-teknova">
</header>