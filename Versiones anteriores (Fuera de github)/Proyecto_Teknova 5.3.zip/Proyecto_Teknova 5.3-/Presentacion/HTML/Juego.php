<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partida de Draftosaurus</title>
    <link rel="stylesheet" href="../CSS/Styles_Base.css">
    <link rel="stylesheet" href="../CSS/Juego.css">
</head>
<?php include_once 'cabecera.php'; ?>
<body class="Partida">
  <header class="barra-superior">
        <section class="Usuario">
            <img class="img-Usuario" src="https://i.imgur.com/dI9Sv1L.png" alt="Foto del Usuario">
            <aside class="NombreyAjustes">
                <h5 class="nombre-Usuario">usuario</h5>
                <a href="Ajustes.html" class="ajustes">Ajustes</a>
            </aside>
        </section>   
        <img src="https://i.imgur.com/Elnz5fv.png" alt="Logo Draftosaurus" class="logo-central">
        <img src="https://i.imgur.com/lNgoRWb.png" alt="Logo Teknova" class="logo-teknova">
  </header>

  <article class="tablero">
    <header class="DinoPuntos" type="text" placeholder="PUNTOS:">PUNTOS:</header> <!-- Puntos -->
    
    <section class="recintos"> <!-- Tablero -->
      <aside> <!-- seccion izquierda del tablero -->
  
        <section class="recinto recinto-1">
          <!-- resinto 1 que contiene r7,r8,r9,r10,r11,r12  -->
          <article class="recinto recinto-7"></article>
          <article class="recinto recinto-8"></article>
          <article class="recinto recinto-9"></article>
          <article class="recinto recinto-10"></article>
          <article class="recinto recinto-11"></article>
          <article class="recinto recinto-12"></article>
        </section>
        
        <section class="recinto recinto-2">
          <!-- resinto 2 que contiene r13,r14,r15 -->
          <article class="recinto recinto-13"></article>
          <article class="recinto recinto-14"></article>
          <article class="recinto recinto-15"></article>
        </section>
  
        <section class="recinto recinto-3">
          <!-- resinto 3 que contiene r16,r17,r18,r19,r20,r21  -->
          <article class="recinto recinto-16"></article>
          <article class="recinto recinto-17"></article>
          <article class="recinto recinto-18"></article>
          <article class="recinto recinto-19"></article>
          <article class="recinto recinto-20"></article>
          <article class="recinto recinto-21"></article>
        </section>
      </aside>
  
      <!-- rio -->
      <article class="Rio">
        <article class="recinto recinto-c4"></article>
        <article class="recinto recinto-c5"></article>
        <article class="recinto recinto-c6"></article>
      </article><!-- rio -->
  
      <aside><!-- seccion derecha del tablero -->
        <section class="recinto recinto-r7">
          <!-- resinto 7 que contiene r6 -->
          <article class="recinto recinto-6"></article>
        </section>
      
        <section class="recinto recinto-r8">
          <!-- resinto 8 que contiene r22,r23,r24,r25,r26,r27  -->
          <article class="recinto recinto-22"></article>
          <article class="recinto recinto-23"></article>
          <article class="recinto recinto-24"></article>
          <article class="recinto recinto-25"></article>
          <article class="recinto recinto-26"></article>
          <article class="recinto recinto-27"></article>
        </section>
      
        <section class="recinto recinto-r9">
          <!-- resinto 9 que contiene r4 -->
          <article class="recinto recinto-4"></article>
        </section>
      </aside>
      
    </section>
  </article>
  <aside class="ContenedorDadoyDinos">
      <section class="toggle-contenedor">
              <img src="https://images.vexels.com/media/users/3/264723/isolated/preview/dd0ea3896edd75f54e62342f8e7e7d85-caja-de-carton-de-dibujos-animados.png" alt="Caja de Dinosaurios" id="toggleDinos">
              <aside class="DinoDado" id="dado">
                  <img src="https://i.imgur.com/aejOyBz.png" alt="cara del dado">
              </aside>
          </section>
  
          <dialog id="toggleDinos2">
              <figure class="dinos" id="listaDinos">
                  <img src="https://i.imgur.com/6akD1K2.png" alt="Dinosaurio-4" class="Dinos">
                  <img src="https://i.imgur.com/YR61Aub.png" alt="Dinosaurio-5" class="Dinos">
                  <img src="https://i.imgur.com/z1WjVCw.png" alt="Dinosaurio-6" class="Dinos">
              </figure>
              <figure class="dinos2" id="listaDinos2">
                  <img src="https://i.imgur.com/hYrkrlG.png" alt="Dinosaurio-1" class="Dinos">
                  <img src="https://i.imgur.com/VimMp4W.png" alt="Dinosaurio-2" class="Dinos">
                  <img src="https://i.imgur.com/tumUHHf.png" alt="Dinosaurio-3" class="Dinos">
              </figure>
              <button id="cerrar">&times;</button>
          </dialog>
  </aside>
  <script src="../JS/juego.js"></script>
</body>
</html>