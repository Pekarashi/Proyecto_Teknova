<?php
session_start();
include("../Datos/solicitudes.php");


$correo = $_POST['usuario'];
$contrasenia = $_POST['password'];

if(!filter_var($correo, FILTER_VALIDATE_EMAIL)){
    $error = urlencode("Usuario o contraseña no válido");
    header("Location: ../Presentacion/HTML/login.php?error=$error");
    exit();
}

if(!filter_var($correo, FILTER_DEFAULT)){
    $error = urlencode("Usuario o contraseña no válido");
    header("Location: ../Presentacion/HTML/login.php?error=$error");
    exit();
}

$solicitudes = new Solicitudes();
$usuario = $solicitudes->login($correo, $contrasenia); 

if($usuario) {
    $_SESSION["usuario_id"] = $usuario->getUsuarioId();
    $_SESSION["usuario"] = $usuario;
    header("Location: ../Presentacion/HTML/Draftosaurus.php");
    exit();
} else {
    header("Location: ../Presentacion/HTML/login.php");
    exit();
}
?>
