<?php
include "../Datos/conexion.php"; 

$correo = $_POST["usuario"];
$contrasenia = $_POST["password"];

$sql = "SELECT * FROM usuario WHERE correo = '$correo' AND contrasenia = '$password'";
$resultado = $conexion->query($sql);
var_dump($_POST);
return;

if ($resultado->num_rows > 0) {
    session_start();
    $usuario = $resultado->fetch_assoc();
    $_SESSION["usuario_id"] = $usuario["id"];
    $_SESSION["usuario_nombre"] = $usuario["nombre"];

    echo "Bienvenido " . $usuario["nombre"];
} else {
    echo "Correo o contraseña incorrectos.";
}

$conexion->close();
?>