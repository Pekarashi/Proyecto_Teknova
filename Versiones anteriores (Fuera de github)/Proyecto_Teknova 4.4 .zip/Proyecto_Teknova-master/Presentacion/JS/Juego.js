const toggleDinos = document.getElementById("toggleDinos"); 
const btnCerrar = document.getElementById("cerrar");       
const toggleDinos2 = document.getElementById("toggleDinos2"); 

if (toggleDinos && toggleDinos2) {
  toggleDinos.addEventListener("click", function() {
    toggleDinos2.style.display = "flex";
  });
}

if (btnCerrar && toggleDinos2) {
  btnCerrar.addEventListener("click", function(e) {
    e.preventDefault();
    toggleDinos2.style.display = "none";
  });
}

var dinos = document.querySelectorAll("#listaDinos .Dinos, #listaDinos2 .Dinos");

var recintos = document.querySelectorAll(".recinto");

var dinoSeleccionado = null;

for (var i = 0; i < dinos.length; i++) {
  dinos[i].addEventListener("click", function() {

    for (var j = 0; j < dinos.length; j++) {
      dinos[j].classList.remove("dino-seleccionado");
    }

    this.classList.add("dino-seleccionado");

    dinoSeleccionado = this;

  });
}

for (var i = 0; i < recintos.length; i++) {
  recintos[i].addEventListener("click", function() {

    if (dinoSeleccionado != null) {

      if (this.children.length == 0) {

        var imgDentro = this.querySelector("img");

        if (imgDentro) {
          imgDentro.parentNode.appendChild(dinoSeleccionado);
        } else {
          this.appendChild(dinoSeleccionado);
        }

        dinoSeleccionado.classList.remove("dino-seleccionado");

        dinoSeleccionado = null;

      } else {

        alert("Este recinto ya tiene un dinosaurio");
      }

    }

  });  
}
