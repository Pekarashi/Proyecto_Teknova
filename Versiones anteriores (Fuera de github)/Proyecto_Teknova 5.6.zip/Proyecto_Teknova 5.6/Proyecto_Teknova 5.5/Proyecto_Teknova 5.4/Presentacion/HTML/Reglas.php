<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Draftosaurus - Reglas</title>
    <link rel="stylesheet" href="../CSS/Styles_Base.css">
    <link rel="stylesheet" href="../CSS/Reglas.css">
    <link rel="icon" href="imagenes/imgPestaña.png">
</head> 
<?php
include_once 'autenticado.php';
include_once 'cabecera.php';
?>
<body class="Reglas">
    <nav id="columna-Breglas">
        <a button href="SelecionarModo.html" class="botonesReglas">Modo de juego</a> 
        <a button href="puntuaciones.html" class="botonesReglas">Puntuaciones</a>
        <a button href="draftosaurus.html" class="botonesReglas">volver al Inicio</a>
    </nav>

<main id="Reglas">
    <section class="container1">
        <h2>Objetivo</h2>
        <p>El objetivo principal en Draftosaurus es construir el parque de dinosaurios más atractivo para los visitantes. Para lograrlo, los jugadores deben colocar estratégicamente dinosaurios en diferentes recintos de su tablero individual, teniendo en cuenta las restricciones de ubicación que cambian con cada turno. El juego implica un proceso de selección y colocación de "dinos" (meeples de dinosaurios) en los recintos, buscando maximizar los puntos de victoria al final de la partida</p>
    </section>
    <section class="container2">
    <h2>Cómo se juega</h2>
        <p>En Draftosaurus, los jugadores tendrán que ir colocando dinosaurios en los distintos recintos para conseguir la máxima cantidad de puntos posible. Estas zonas, además de no puntuar igual, tienen una regla que hay que cumplir para que el parque siga en armonía. El juego consta de 2 rondas de juego divididas cada una de ellas en 6 turnos que se juegan exactamente igual. Antes de empezar en cada ronda, todos los jugadores sacarán de la bolsa sin mirar 6 dinosaurios que ocultarán en su mano al resto de jugadores.</p>
        <p>Teniendo en cuenta todo esto, organizar nuestro zoológico de dinosaurios parece una tarea fácil ¿me equivoco? Pues sí, porque no lo es. No podremos colocar los 6 dinosaurios que hemos sacado de la bolsa. Tan solo nos quedaremos con uno de ellos y el resto los pasaremos al siguiente jugador. Y para rizar el rizo el jugador inicial, que cambiará en cada turno, será el encargado de lanzar el dado con el que se indicará una regla extra a cumplir durante el turno en curso. Ahora sí que parece un poco caótico el parque tan bonito que os habíais montado en vuestras cabecitas ¿verdad?</p>
        <p>En primer lugar, el jugador inicial lanza el dado y los jugadores sabrán en qué recintos podrán colocar sus dinosaurios. Cuando cada jugador tenga claro qué dinosaurio de su mano quiere colocar en su parque, se revela el dinosaurio escogido y se coloca en el tablero de juego.</p>
        <p>Hay que tener en cuenta dos apuntes. El jugador que tira el dado será el único que no está obligado a cumplir con la regla del dado, por lo que podrá colocar su dinosaurio donde quiera siempre que el resto de reglas del juego lo permitan. Por otro lado, en el caso de que algún jugador no pueda o quiera colocar un dinosaurio, podrá descartarlo en el río.</p>
        <p>Cuando todos hayan colocado sus dinosaurios, los restantes se pasan al jugador de la izquierda, por lo que a todos también nos llegarán nuevos dinosaurios para seguir organizando el zoológico.</p>
        <p>Una vez se hayan colocado 6 dinosaurios en cada tablero comienza la segunda ronda, donde los jugadores volverán a sacar de la bolsa 6 dinosaurios y jugarán como lo han hecho durante la primera ronda, pero manteniendo los dinosaurios colocados en sus tableros.</p>
        <p>Paso a explicar las distintas áreas del tablero de verano del juego de mesa Draftosaurus:</p>
    <ul>
        <li>El Bosque de la Semejanza: en este recinto tan solo se pueden poner dinosaurios de la misma especie.</li>
        <li>El Prado de la Diferencia: este recinto puede llegar a albergar dinosaurios de distintas especies, por lo que no podremos repetir.</li>
        <li>La Pradera del Amor: se colocan parejas de la misma especie hasta llegar a un máximo de 6 dinosaurios.</li>
        <li>El Trío Frondoso: para puntuar hay que colocar exactamente 3 dinosaurios, sean cuales sean.</li>
        <li>El Rey de la Selva: nos llevaremos 7 puntos si ponemos un dinosaurio y nuestro parque es el que más dinosaurios tiene de esa especie.</li>
        <li>La Isla Solitaria: si queremos conseguir los puntos , el dinosaurio que dejemos en este recinto no puede estar en ningún otro del parque.</li>
        <li>Río: no se considera un recinto del zoo pero sí puntuará con 1 punto por dinosaurio al final de la partida.</li>
    </ul>
    </section>

    <section class="container3">
        <p>¡A tener en cuenta! El T-Rex es único y especial, de ahí que por cada recinto que contenga uno de ellos nos llevaremos otro punto adicional.</p>
        <p>El dado, como he comentado, nos forzará a colocar un dinosaurio en un recinto del tablero salvo que seamos el que lo ha tirado o prefiramos descartarlo para no perder puntos. Este dado nos puede obligar a colocar dinosaurios en los recintos que se encuentren en el bosque (arriba) o en la llanura (abajo). También puede hacernos colocarlos en la zona de la derecha del río (en la zona de aseos) o a la izquierda del mismo (cerca de la cafetería). Por último, nos puede forzar a ponerlos en una zona dependiendo de como hayamos desarrollado el tablero colocándolo en un recinto que todavía tengamos vacío o en un lugar donde no haya ningún T-Rex.</p>
        <p>La partida de Draftosaurus finaliza al terminar la segunda ronda, cuando todos los jugadores tienen 12 dinosaurios en sus respectivos parques. En este momento, los jugadores cuentan los puntos conseguidos en cada zona del parque según se especifica en el tablero, ganando el jugador que tiene una mayor cantidad de puntos. En caso de un hipotético empate, ganará el que tenga menos T-Rex.</p>
        <h3>Fin de la partida</h3>
    <footer>
        <p class="Pie-de-la-Pagina">&copy; 2025 - Proyecto de Egreso</p>
    </footer>
    </section>
</main>
</body>
</html>