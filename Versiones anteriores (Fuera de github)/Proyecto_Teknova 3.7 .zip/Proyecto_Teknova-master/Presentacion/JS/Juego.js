 const toggleDinos = document.getElementById("toggleDinos");
    const dialog = document.querySelector("dialog");
    const listaDinos = document.getElementById("listaDinos");
    const btnCerrar = document.querySelector("#cerrar");

    toggleDinos.addEventListener("click", () => {
        listaDinos.classList.toggle("activo");
        toggleDinos.alt = listaDinos.classList.contains("activo")
        ? "Dinosaurios ocultos"
        : "Dinosaurios visibles";
        dialog.showModal();
    })

    btnCerrar.addEventListener("click", () => {
    dialog.close();
    listaDinos.classList.remove("activo");  // Cambiar toggle por remove
    toggleDinos.alt = listaDinos.classList.contains("activo")
        ? "Dinosaurios ocultos"
        : "Dinosaurios visibles";
});