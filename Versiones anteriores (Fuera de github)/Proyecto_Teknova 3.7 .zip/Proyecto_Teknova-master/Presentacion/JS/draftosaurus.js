const sidebar = document.getElementById("sidebar");
const toggleBtn = document.getElementById("toggleBtn");

// Estado inicial
let abierto = false;

// Seleccionamos todos los toggles
const toggles = document.querySelectorAll(".toggle-dinos");

toggles.forEach(toggle => {
    toggle.addEventListener("click", () => {
        // Encuentra el contenedor hermano con la clase "dinos"
        const dinosContainer = toggle.nextElementSibling;

        // Alterna la clase "activo" para mostrar/ocultar
        dinosContainer.classList.toggle("activo");
    });
});
