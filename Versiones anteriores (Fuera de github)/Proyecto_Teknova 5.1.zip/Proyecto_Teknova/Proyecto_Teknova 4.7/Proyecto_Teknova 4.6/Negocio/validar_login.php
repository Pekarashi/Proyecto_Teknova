<?php
include("../Datos/solicitudes.php");


$correo = $_POST['usuario'];
$contrasenia = $_POST['password'];

$solicitudes = new Solicitudes();
$usuario = $solicitudes->login($correo, $contrasenia); 

if($usuario) {
    echo " Login correcto"; //logica de sesión y redirigir al usuario
} else {
    echo " Usuario o contraseña incorrectos"; //mensaje de error
}
?>
