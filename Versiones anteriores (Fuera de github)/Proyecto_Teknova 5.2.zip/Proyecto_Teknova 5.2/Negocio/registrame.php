<?php
include "../Datos/conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST["nombre"]);
    $correo = trim($_POST["correo"]);
    $password = $_POST["password"];

    if (empty($nombre) || empty($correo) || empty($password)) {
        echo "Por favor, completa todos los campos.";
    } else {

        $stmt = $conexion->prepare("INSERT INTO usuario (nombre, correo, contrasenia) VALUES (?, ?, ?)");
        if ($stmt === false) {
            die("Error en la preparación de la consulta: " . $conexion->error);
        }
        $stmt->bind_param("sss", $nombre, $correo, $password);
        if ($stmt->execute()) {
            echo "Usuario registrado con éxito. <a href='../Presentacion../HTML/login.html'>Iniciar sesión</a>";
        } else {
            echo "Error al registrar usuario: " . $stmt->error;
        }
        $stmt->close();
        $conexion->close();
    }
}
?>
