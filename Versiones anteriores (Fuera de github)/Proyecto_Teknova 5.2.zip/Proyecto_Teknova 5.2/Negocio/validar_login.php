<?php
include("../Datos/conexion.php");

$correo = $_POST['usuario'];
$contrasenia = $_POST['password'];

$consulta = $conexion->query(query: "SELECT * FROM usuario WHERE correo='$correo' AND password='$contrasenia'");

if ($consulta && $consulta->num_rows > 0) {
    echo " Login correcto";
} else {
    echo " Usuario o contraseña incorrectos";
}
?>
